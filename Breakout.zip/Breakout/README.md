Fredrik og Gustav sin versjon av breakout
Hei Rasmus
meny.py er startsiden
Det er bare på trykk på escape-knappen for å gå tilbake til en tidligere side
Anbefaling: Spill med lyd 
Det kan hende du må korrigere hvor lyd-effekten kommer fra